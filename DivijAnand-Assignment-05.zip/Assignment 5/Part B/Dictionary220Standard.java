package javaDictionaryCSC220;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import java.util.Collection;
import java.util.Scanner;

public class Dictionary220Standard {

    //all the enum entries as per the output in the assignment manual

    private enum Entry {
        BOOK1("book", "A written work published in printed or electronic form."),
        BOOK2("book", "To arrange for someone to have a seat on a plane."),
        BOOKABLE("bookable", "Can be ordered in advance."),
        BOOKCASE("bookcase", "A piece of furniture with shelves."),
        BOOKBINDER("bookbinder", "A person who fastens the pages of books."),
        CSC220_1("csc220", "Data Structures."),
        CSC220_2("csc220", "Ready to create complex data structures."),
        CSC220_3("csc220", "To create data structures.");

        private final String key;
        private final String value;

        Entry(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }
    }

    public static void main(String[] args) {
        Multimap<String, String> dictionary = ArrayListMultimap.create(); //loading enums
        for (Entry entry : Entry.values()) {
            dictionary.put(entry.getKey().toLowerCase(), entry.getValue());
        }

        Scanner scanner = new Scanner(System.in); //scanner is active and activates loop
        System.out.println("- DICTIONARY 220 JAVA Standard -----");
        System.out.println("-----      powered by Google Guava -");

        while (true) {
            System.out.print("\nSearch: ");
            String input = scanner.nextLine().toLowerCase();

            if (input.equals("!q")) {
                break;
            }

            System.out.println(" |");
            if (dictionary.containsKey(input)) {
                Collection<String> results = dictionary.get(input);
                for (String def : results) {
                    System.out.println("  " + capitalize(input) + ": " + def);
                }
            } else {
                System.out.println("  <Not found>");
            }
            System.out.println(" |");
        }

        System.out.println("\n-----THANK YOU-----");
    }

    private static String capitalize(String word) {
        if (word.isEmpty()) return word;
        return Character.toUpperCase(word.charAt(0)) + word.substring(1).toLowerCase();
    }
}
